import { Component, OnInit } from '@angular/core';
import {AppComponent1} from './app.component1';
import {FriendComponent} from './friend.component';
import { FriendService } from './friend.service';

@Component({
 selector: 'my-app',
 directives: [FriendComponent],
 //templateUrl: 'app/app.component.html'
 template: `
  <h2>Hello from the {{componentName}}!</h2>
  <div *ngFor="#f of friends">
   <h4> Name : {{f.name}} </h4> <h4>Age: {{f.age}}</h4>
  </div>
  `
})

export class AppComponent implements OnInit {

    componentName: 'AppComponent';

    ngOnInit() {
    }
  }
