import { Component } from '@angular/core';
import {OnInit } from '@angular/core';

@Component({
  selector: 'my-app2',
  templateUrl: 'app.component2.html',
  styleUrls: ['app.component2.css'],
})
export class AppComponent2 implements OnInit {

  ngOnInit() {
    var toto = 'toto';
  }

 }
