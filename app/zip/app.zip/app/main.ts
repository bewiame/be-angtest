import { bootstrap } from '@angular/platform-browser-dynamic';
import { AppComponent } from './app.component';
//import { AppComponent1 } from './app.component1';
//import { AppComponent2 } from './app.component2';
bootstrap(AppComponent);
//bootstrap(AppComponent1);
//bootstrap(AppComponent2);
