"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var app_component_1 = require('./app.component');
//import { AppComponent1 } from './app.component1';
//import { AppComponent2 } from './app.component2';
platform_browser_dynamic_1.bootstrap(app_component_1.AppComponent);
//bootstrap(AppComponent1);
//bootstrap(AppComponent2);
//# sourceMappingURL=main.js.map