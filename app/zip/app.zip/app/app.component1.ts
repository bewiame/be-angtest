import { Component } from '@angular/core';
@Component({
selector: 'my-app1',
template: '<h1>My First Angular 2 Component - in live - AppComponent1</h1>'
})
export class AppComponent1 { }
